<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.datatables.net/2.0.5/css/dataTables.dataTables.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">

    <style>
        table,th,td{
            border: 2px solid black;
            border-collapse: collapse;
        }
    </style>
</head>

<body>
    <div class="container">
    <table id="myTable">
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>URL</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($d->name); ?></td>
                    <td><?php echo e($d->email); ?></td>
                    <td><a href="<?php echo e($d->certificate_url); ?>" class="btn btn-primary" target="_blank">Show Certificate</a></td>
                    <td>
                        <a href="<?php echo e(route('data.delete', ['id' => $d->id])); ?>" class="btn btn-danger">Delete</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
    <script src="<?php echo e(asset('assets/js/jquery-3-6-0.min.js')); ?>"></script>
    <script src="https://cdn.datatables.net/2.0.5/js/dataTables.min.js"></script>
    <script>
        $(document).ready(function(){
            $('#myTable').DataTable();
        });
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\trusted-form\resources\views/admin/data.blade.php ENDPATH**/ ?>